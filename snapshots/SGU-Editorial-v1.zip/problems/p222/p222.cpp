#include <bits/stdc++.h>
#define endl '\n'

// #pragma GCC optimize ("O3")
// #pragma GCC target ("sse4")

#define SZ(x) ((int)x.size())
#define ALL(V) V.begin(), V.end()
#define L_B lower_bound
#define U_B upper_bound
#define pb push_back

using namespace std;
template<class T, class T2>
inline int chkmax(T& x, const T2& y) {
    return x < y ? x = y, 1 : 0;
}
template<class T, class T2>
inline int chkmin(T& x, const T2& y) {
    return x > y ? x = y, 1 : 0;
}
const int MAXN = (1 << 20);

int n, k;

void read() { cin >> n >> k; }

void solve() {
    if(n < k) {
        cout << 0 << endl;
        return;
    }

    int64_t answer = 1;
    for(int i = 1; i <= n; i++) {
        answer *= i * i;
    }
    for(int i = 1; i <= k; i++) {
        answer /= i;
    }
    for(int i = 1; i <= n - k; i++) {
        answer /= i * i;
    }
    cout << answer << endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    read();
    solve();
    return 0;
}
