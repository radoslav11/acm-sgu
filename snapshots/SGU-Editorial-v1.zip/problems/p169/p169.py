n = int(input())

if n == 1:
    print(8)
elif n % 6 == 1:
    print(4)
elif n % 3 == 1:
    print(3)
else:
    print(1)
